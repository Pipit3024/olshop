<?php
// Koneksi ke database
$servername = "localhost";  
$username = "root";         
$password = "";             
$dbname = "tokoujian";       

$conn = mysqli_connect($servername, $username, $password, $dbname);

// Cek koneksi
if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error());
}

session_start();
$error = ''; // Inisialisasi variabel $error

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = $_POST['password'];

    $query = "SELECT * FROM users WHERE email='$email'";
    $result = mysqli_query($conn, $query);

    if (mysqli_num_rows($result) > 0) {
        $user = mysqli_fetch_assoc($result);

        if ($password === $user['password']) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['role'] = $user['role'];

            if ($user['role'] === 'admin') {
                header('Location: ../Admin/dashboard.php');
            } else {
                header('Location: ../index.php');
            }
        } else {
            $error = "Email atau password salah!";
        }
    } else {
        $error = "Email tidak ditemukan!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #2c3e50;
            font-family: 'Arial', sans-serif;
        }

        .container {
            margin-top: 100px;
        }

        .card {
            border-radius: 15px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }

        .card-header {
            background-color: #1abc9c;
            color: #ffffff;
            border-radius: 15px 15px 0 0;
            text-align: center;
        }

        .card-title {
            margin: 10px 0;
        }

        .card-body {
            padding: 30px;
            background-color: #ecf0f1;
        }

        .form-group label {
            font-weight: bold;
            color: #34495e;
        }

        .form-control {
            background-color: #fdfefe;
            border: 1px solid #dcdde1;
            color: #2c3e50;
        }

        .form-control:focus {
            box-shadow: none;
            border-color: #1abc9c;
        }

        .btn-primary {
            background-color: #1abc9c;
            border: none;
            transition: background-color 0.3s ease;
        }

        .btn-primary:hover {
            background-color: #16a085;
        }

        .alert-danger {
            background-color: #e74c3c;
            color: #ffffff;
            border: none;
        }

        .text-center a {
            color: #1abc9c;
        }

        .text-center a:hover {
            text-decoration: underline;
            color: #16a085;
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">
                    <header class="card-header">
                        <h4 class="card-title">Login</h4>
                    </header>
                    <article class="card-body">
                        <?php if ($error): ?>
                            <div class="alert alert-danger" role="alert">
                                <?= htmlspecialchars($error); ?>
                            </div>
                        <?php endif; ?>
                        <form method="post" action="">
                            <div class="form-group">
                                <label for="email">Email:</label>
                                <input type="email" class="form-control" id="email" name="email" required>
                            </div>
                            <div class="form-group">
                                <label for="password">Password:</label>
                                <input type="password" class="form-control" id="password" name="password" required>
                            </div>
                            <div class="form-group">
                                <button type="submit" class="btn btn-primary btn-block">Login</button>
                            </div>
                        </form>
                    </article>
                    <div class="border-top card-body text-center">
                        Don't have an account? <a href="register.php">Register</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

</html>
